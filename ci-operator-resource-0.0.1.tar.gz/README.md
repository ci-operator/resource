ci-operator/resource role
Deploy/update Openshift/Kubernetes resource objects
